import { EventEmitter, Output } from '@angular/core';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-game-control',
  templateUrl: './game-control.component.html',
  styleUrls: ['./game-control.component.css']
})
export class GameControlComponent implements OnInit {

  constructor() { }
TimeInterval;
CurrentNumber=0;
@Output()Increment=new EventEmitter<number>();
  ngOnInit(): void {
  }
  onStart()
  {
    this.TimeInterval = setInterval(() => {
      this.Increment.emit(this.CurrentNumber);
      this.CurrentNumber += 1;
    }, 1000);
  }

  onStop()
  {
    clearInterval(this.TimeInterval);
  }
}
