import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  oddnumbers=[];
  evennumbers=[];
  checking(NumberPassed : number)
  {
    if(NumberPassed %2===0)
    {
      this.evennumbers.push(NumberPassed);
    }
    else{
      this.oddnumbers.push(NumberPassed);
    }
  }
}
